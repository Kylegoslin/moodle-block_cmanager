<?php
/*    
 * Moodle Course Manager
 * 
 *    verison.php 
 * 
 */
$plugin->version   = 2012042504;      // The current module version (Date: YYYYMMDDXX)
$plugin->requires  = 2010031900;      // Requires this Moodle version

