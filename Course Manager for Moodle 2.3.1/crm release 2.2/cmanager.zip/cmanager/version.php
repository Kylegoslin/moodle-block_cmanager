<?php
/*    
 * Moodle Course Manager
 * 
 *    verison.php 
 * 
 */
$plugin->version = 2012072522;      // The current module version (Date: YYYYMMDDXX)
$plugin->requires = 2012062501.00;      // Requires this Moodle version

$plugin->maturity = MATURITY_STABLE;
$plugin->release = '2.2';
?>



